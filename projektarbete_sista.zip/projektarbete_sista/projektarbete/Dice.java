package projektarbete;
/**Object Dice POJO */
public class Dice {
    private int currentrandomnum;
    private int id;

    public Dice(int currentrandomnum, int id) {
        this.currentrandomnum = currentrandomnum;
        this.id = id;
    }
    public int getCurrentrandomnum() {
        return currentrandomnum;
    }
    public void setCurrentrandomnum(int currentrandomnum) {
        this.currentrandomnum = currentrandomnum;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
}
