package projektarbete;
/** Class shows final results*/
public class FinnishGame {
    public static void sameDiceRestart(){
        System.out.println("***********************************************************************************");
        System.out.println("            LUCKY! ;) [ CRAZY DICES ARE THE SAME ] / [ GAME WILL RESTART ]");
        System.out.println("***********************************************************************************");
        InGame.input();
    }
    public static void sameScore(){
        System.out.println("*******************************************************************************");
        System.out.println("                    [ THE SAME SCORE ] [:)]");
        System.out.println("*******************************************************************************");
        InGame.input();
    }
    public static void finalSummary(Player [] p,int totalroundstries,int totalgameround,int tsamedice){
        System.out.println("**************************[FINAL SUMMARY]*************************************************");
        System.out.println("*[TOTAL ROUNDS, YOU GOT THE SAME CRAZY DICES] = ["+tsamedice+"]");
        System.out.println("*[TOTAL ROUNDS PLAYED] = ["+totalroundstries+"] / ["+totalgameround+"]");
        InGame.roundSummary(p); //method take parameters and shows  player1 extra info
        //method take parameters and shows  player2  extra info
        System.out.println("************************************************************************************");
        InGame.input(); //Method, Call a user entrance
    }
}
