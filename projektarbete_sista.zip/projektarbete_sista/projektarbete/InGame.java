package projektarbete;
import java.util.Random;
import java.util.Scanner;
/** CLASS SUB MAIN IN GAME*/
public class InGame {
    //Method return a random number between 1-6 / this is the virtual dice
    public static int rollingTheDice() {
        Random rand = new Random();
        return (rand.nextInt(6) + 1); //special method som returner en random number
    }
    public static void showRollDice(Player[] p, int i) {
        System.out.print("[ "+ p[i].getPlayerName() + " ] ROLL THE DICE NOW ;) ");
    }
    public static void showDice( Player[] p,int i,int d) {
        //changes
        System.out.println("[ "+p[i].getPlayerName()+" ] GET  <<< " + d + " >>> [CRAZY POINTS]  [(::)] + [(::)]");
    }
    //Sub-main game
    public static void playerControll(Player[] p, Dice[] d, int i) {
        int rand;
        int totalrand = 0;
        showRollDice(p, i);
        input();
        for (int j = 0; j < 2; j++) {
            rand = rollingTheDice();
            d[j].setCurrentrandomnum(rand);
            totalrand = totalrand + rand;
        }
        p[i].setPoints(totalrand);
        showDice(p,i,totalrand); //changes p,i
    }
    public static void failUserEntrance() {
        System.out.println("-------------------------------------------");
        System.out.print("--> [ Fail User Entrance ]  ");
        input();
    }
    public static void input() {
        Scanner s = new Scanner(System.in);
        System.out.print("<-- Press [ENTER] key");
        s.nextLine();
    }
    public static void restartPlayersValues(Player[] p) {
        for (Player player : p) {
            player.setTotalpoints(0);
        }
    }
    //Method take parameters and show info about current ROUND and Players
    public static void showRound(Player[] p, int c, int ttries) {
        System.out.println("************************************************************************************");
        if(c==0){
            System.out.println("                         GAME HAS STARTED [*-*], GOD LUCK!     ");
            System.out.println("************************************************************************************");
             }else{
                System.out.println("                          ROUND [" + c + "] [*-*], COMPLETE :) "   );
                System.out.println("************************************************************************************");
                for (Player player : p) {
                System.out.println("[ " + player.getPlayerName() + " ]  |  [Total Crazy Points  < " + player.getTotalpoints() +" > ]   |   [Current Tries=" + ttries + "]");
                }
            System.out.println("************************************************************************************");
            }
    }
    public static void roundSummary(Player[] p) {
        for (Player player : p) {
            System.out.println("*PLAYER[" + player.getId() + "][ " + player.getPlayerName() + " ] / [Total Crazy Points] = [" + player.getTotalpoints() + "]");
        }
    }
    public static void instructions() {
        System.out.println("*************************************************************************************");
        System.out.println("                      [CRAZY LUCKY  [DICE]]  [A LUCKY GAME]");
        System.out.println("*************************************************************************************");
        System.out.println("      [*-*] {Readme}");
        System.out.println("      *Roll the Dice and play with friends");
        System.out.println("      *There are two Abstract crazy dices in movement ");
        System.out.println("      *Default players = [2]");
        System.out.println("      *Default rounds = [2]");
        System.out.println("      *You can change [Total players] [recommended from 2 to 8] max=10");
        System.out.println("      *If you have the [Same total points] as your friends in a round,");
        System.out.println("      so then [the game and total points] will be restarted from the beginning");
        System.out.println("      If not, the [Final score] will decide a Winner/s or deuce ");
        System.out.println("      *Game can match many winners if highest score are the same ");
        System.out.println("      *Open minds are necessaries for regards");
    }
    //OKAY
    public static int checkSameResultat(Player[] p) {
        int count = 0;
        int temp = p[0].getPoints();
        for (Player player : p) {
            if (temp == player.getPoints())
                count++;
        }
        return (count);
    }
    public static void checkTheWinner(Player[] p) {
        int maxpoints = 0;
        for (Player player : p) {
            if (player.getTotalpoints() > maxpoints) {
                maxpoints = player.getTotalpoints();
            }
        }
        for (Player player : p) {
            if (maxpoints == player.getTotalpoints())
                player.showWinner();
        }
        InGame.input();
    }
    public static int checkSameFinalScore(Player[] p) {
        int count = 0;
        int temp = p[0].getTotalpoints();
        for (Player player : p) {
            if (temp == player.getTotalpoints())
                count++;
        }
        return (count);
    }
}
