package projektarbete;
import java.util.Objects;
import java.util.Scanner;
/**CLASS MAIN GAME*/
public class Main {
    static final int totalgameround =2; //Default game rounds
    public static void main(String[] args) {
        boolean mmenu = true;
        String username;
        int totalplayer = 2; //defaults total players
        Scanner myscanner = new Scanner(System.in);
        //Creating Instances of objects "Players and Dices"
        InGame.instructions(); //Show the first user menu
        do {
            switch (startMenu(myscanner)) {
                case "1" -> {
                    Player[] player = new Player[totalplayer];
                    Dice[] dice = new Dice[totalplayer];
                    System.out.println("*********************************************************************************");
                    System.out.println("                             [USER SETTINGS]");
                    System.out.println("*********************************************************************************");
                    for (int i = 0; i < totalplayer; i++) {
                        //Setting some attributes to the object "player"

                        System.out.print("*[Player [" + (i + 1) + "]] [Alias] <--: ");
                        username = myscanner.nextLine();
                        player[i] = new Player(username, 0, 0, i + 1);
                        dice[i] = new Dice(0, i + 1);
                    }
                    if(totalplayer==2){
                        System.out.println("[Default Values] [Total players] = "+ totalplayer);
                        System.out.println("[Default Values] [Total Game rounds] = "+ totalgameround);
                    }else{
                        System.out.println("[Total selected players] = "+ totalplayer);
                        System.out.println("[Total Game rounds selected] = "+ totalgameround);
                    }
                    //Start the game Method
                    startGame(player, dice, totalplayer);
                }
                case "2" -> {
                    System.out.print("Amount of players recommended: [2-3-4-5-6] --> "); //okay
                    try {
                        username = myscanner.nextLine();
                        int in = Integer.parseInt(username);
                        if (in < 2 || in > 10) {
                            System.out.println("[ Number of player available [ 2 - 10 ] ] ");
                            System.out.print("[ TRY AGAIN ] ");
                            InGame.input();
                        } else {
                            totalplayer = in; //Add New total player
                            System.out.println("Setting [ NEW total players] = [ " + in + " ] --> OKAY");
                        }
                    } catch (Exception e) {
                        System.out.print("--> Fel input data:[Please use numbers] ");
                        InGame.input();
                    }
                }
                case "3" -> {
                    InGame.instructions();
                    System.out.println("****************************************************************************************");
                    InGame.input();//Method shows press enter key and wait user input
                }
                case "4" -> mmenu = false;
                default -> InGame.failUserEntrance();
            }
        } while (mmenu );
    }
    //main control game method
    public static void startGame(Player[] p, Dice[] d,int totalplayer){
        int currentround; int totalroundstries=0; int totalsamedice=0;
        int i=0;
        //Game start at less one round . fix it! :)
        do {
            currentround=i; //+1 Variable  it will save the total rounds player
            InGame.showRound(p,currentround,totalroundstries);//okay
           //InGame.input(); //okay
            for (int j=0;j<totalplayer;j++) {
                InGame.playerControll(p, d,j);//Method set player1 control okay
                InGame.input();//okay
                p[j].setTotalpoints(p[j].getTotalpoints()+p[j].getPoints());//okay
            }
            if(InGame.checkSameResultat(p)==totalplayer){ //ok
                i=0;
                FinnishGame.sameDiceRestart();
                InGame.restartPlayersValues(p);
                totalsamedice++;
            }
                else i++;
                ++totalroundstries;//Variable save total rounds of same dices in the hole game /shows in the summary
        }while ((i<totalgameround));
        if(InGame.checkSameFinalScore(p)==totalplayer)
        FinnishGame.sameScore();
           else InGame.checkTheWinner(p); //total players
        FinnishGame.finalSummary(p,totalroundstries,totalgameround,totalsamedice); //okay
    }
    //Main menu method , return user entrance
    public static String startMenu(Scanner s){
        System.out.println("*************************************************************************************");
        System.out.println("                                 [MAIN MENU]                                    ");
        System.out.println("*************************************************************************************");
        System.out.println("[1] --> [Start] a [NEW] game");
        System.out.println("[2] --> [Set] Total players");
        System.out.println("[3] --> [Show] Instructions");
        System.out.println("[4] --> [Close] the game      ");
        System.out.print("[ ] <-- Number: ");
        return  s.nextLine();
    }
}
