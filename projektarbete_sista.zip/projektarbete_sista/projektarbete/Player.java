package projektarbete;
/**Object player POJO + interface Implements */
public class Player implements playerI {
    private String playerName;
    private int points;
    private int totalpoints;
    private int id;
    public Player(String playerName, int points, int totalpoints, int id) {
        this.playerName = playerName;
        this.points = points;
        this.totalpoints = totalpoints;
        this.id = id;
    }
    public String getPlayerName() {
        return playerName;
    }
    public void setPlayerName(String playerName) {
        this.playerName = playerName;
    }
    public int getPoints() {
        return points;
    }
    public void setPoints(int points) {
        this.points = points;
    }
    public int getTotalpoints() {
        return totalpoints;
    }
    public void setTotalpoints(int totalpoints) {
        this.totalpoints = totalpoints;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    @Override
    public void showWinner() {
        System.out.println("***********************************************************************************");
        System.out.println("                        PLAYER [ "+ playerName     +" ] WON :)");
        System.out.println("***********************************************************************************");
    }
}
