package projektarbete;
/** Interface player implement two method*/
public interface playerI {
    void showWinner(); //Show the WINNER of the game
}
